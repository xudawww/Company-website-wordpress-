<?php
/**
 * Raised when the Braintree library is not completely configured.
 *
 * @package    Braintree
 * @subpackage Exception
 * @see        Braintree_Configuration
 */
class Braintree_Exception_Configuration extends Braintree_Exception
{

}
