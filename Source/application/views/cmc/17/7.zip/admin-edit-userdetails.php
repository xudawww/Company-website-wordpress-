

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url();?>assets/dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="<?php echo base_url();?>assets/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php
	 include"uploads/admin_header.php";
	 ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> Edit User Details</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                        Edit User Details
                         <div class="edituser"></div>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                <?php
								 $id = $_GET['id2'];
						  
		 $query = $this->db->query("SELECT * FROM  userdetails WHERE  id ='$id'");
		 $row = $query->row('userdetails');
								?>
                                    <form role="form"  method="post" id="user_reg">
                                        
                                       
                                        <div class="form-group">
                                            <label>Username</label>
                                           <input class="form-control regcom" placeholder="Username" name="username" id="signup-username" value="<?php echo $row->username; ?>" readonly>
                                        </div>
                                         <div class="form-group">
                                            <label>Password</label>
                                           <input class="form-control regcom" placeholder="Password" name="password" id="signup-password" type="password"  value="<?php echo $row->password; ?>" readonly>
                                        </div>
                                        
                                         <div class="form-group">
                                            <label>Email</label>
                                            <input class="form-control regcom" placeholder="E-mail" name="email"  id="signup-email" value="<?php echo $row->email; ?>"readonly>
                                            
                                        </div>
                                        <div class="form-group">
                                            <label>Mobile</label>
                                            <input class="form-control regcom" placeholder="Mobile" name="mobile" id="signup-mobile" value="<?php echo $row->mobile; ?>">
                                        </div>
                                         <div class="form-group">
                                       
                                        <input type="button" class="btn btn-primary" value="Save Details"  name="Save" id="useredit">
                                        
                                      
                                        <input  name="id"   value="<?php echo $row->id; ?>" type="hidden">
                                       </div>
                                        
                                        </div>
                                        <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Gender</label><br>

                                            <label class="radio-inline">
                                                <input type="radio" name="gender" id="optionsRadiosInline1" value="male"  <?php if($row->gender=='male') {echo "checked";} ?> >Male
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="gender" id="optionsRadiosInline2" value="female"  <?php if($row->gender=='female'){echo "checked";} ?>>Female
                                            </label>
                                            
                                        </div>
                                         
                                         <div class="form-group">
                                            <label>Date of Birth</label>
                                            <input class="form-control datepicker" placeholder="DD/MM/YYYY" name="dob"  id="optionD" value="<?php echo $row->dob; ?>">
                                           
                                        </div>
                                         <div class="form-group">
                                            <label>Anniversary Date</label>
                                            <input class="form-control datepicker" placeholder="DD/MM/YYYY" name="anniversary_date"  id="result" value="<?php echo $row->anniversary_date; ?>">
                                            
                                        </div>
                                        
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                              
                               
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url();?>assets/dist/js/sb-admin-2.js"></script>
    
    
    
    
    
    
    
      <!--/column1-->
      <!-- /datepicker -->
      
    
      
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css" />
        <script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     <script type="text/javascript">
$(document).ready(function(){
	$( ".datepicker" ).datepicker({
		
		changeMonth: true,
        changeYear: true,
		yearRange: '1910:2010'




});			   
						   
$('.regcom').on('change', function (){
																		   var a = $(this).val();
																		   if(a != '') {
																			   $(this).removeClass('error-admin');
																		   } else {
																			    $(this).addClass('error-admin');
																		   }
																			  
																	  });						   
						   
						   
 $('#useredit').click(function(){	
	

var mobile = $('#signup-mobile').val();

 var pattern = /^\d{10}$/;
 if(!pattern.test(mobile)){
	   $("#signup-mobile").addClass('error-admin');
	    $("#signup-mobile").focus();
		return false;
   }


								
								
								
var value =$("#user_reg").serialize() ;

$.ajax({
url:'<?php echo base_url();?>admin/updateuser',
type:'post',
data:value,
success:function(contact){
	$(".edituser").show();
console.log(contact);
if(contact==1){
$(".edituser").html('<p class="success">User details updated successfully</p>');
setTimeout(function(){$(".adminuser1").hide(); }, 1500);
window.location.href="<?php echo base_url();?>index.php/admin/dashboard";

}
else{
$(".edituser").html('<p class="error">Sorry Error Occured!!!</p>');
setTimeout(function(){$(".adminuser1").hide(); }, 1500);
}
}
});  
});  
});





</script>


</body>

</html>
