
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url();?>assets/dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="<?php echo base_url();?>assets/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php
	 include"uploads/admin_header.php";
	 ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Settings</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                       Settings
                        <?php
if(($this->session->flashdata('item'))) {
  $message = $this->session->flashdata('item');
  ?>
<div id="mess" class="<?php echo $message['class'];?>"><?php echo $message['message']; ?></div>
<?php
}else{
}

  $query = $this->db->query(" SELECT * FROM `settings` order by id DESC ");
		$row = $query->row('settings');
?>

                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                              
                                   <?php echo form_open_multipart('admin/upload');?>
                                   
                                         <div class="form-group">
                                            <label>Site Title</label>
                                        <input  id="title" name="title" type="text" class="form-control regcom" value="<?php echo $row->title; ?>">
                                        </div>
                                       
                                         <div class="form-group">
                                          <div class="row">
                                           <div class="col-lg-12">
                                          <div class="col-sm-6">
                                            <label>Logo</label>
                                           <input class="regcom"  name="logo"  id="logo" type="file" value="<?php echo $row->logo; ?>">
                                           </div>
                                          <div class="col-sm-6 text-right">
                                           <?php
										   $logo =$row->logo;
										   if($logo){
											   ?>
                                               <img src="<?php echo base_url();?><?php echo $row->logo; ?>">
											   <?php
										   }
										   ?>
                                           </div>
                                        </div>
                                        </div>
                                        </div>
                                         <div class="form-group">
                                            <label>Site Url</label>
                                            <input class="form-control regcom"  name="url"  id="url" value="<?php echo $row->url; ?>">
                                           
                                        </div>
                                        <div class="form-group">
                                            <label>Tag line</label>
                                            <input class="form-control regcom" name="tagline"  id="tag" value="<?php echo $row->tagline; ?>">
                                           
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="intrate">Smtp Username</label>
                                            <input class="form-control regcom" name="smtp_username" id="smtp_username" value="<?php echo $row->smtp_username; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label class="intrate">Smtp Host</label>
                                            <input class="form-control regcom" name="smtp_host" id="smtp_host" value="<?php echo $row->smtp_host; ?>" >
                                        </div>
                                       <div class="form-group">
                                       
                                        <input type="submit" class="btn btn-primary" value="Save"  name="Save" id="taxiadd">
                                        <button type="reset" class="btn btn-primary">Reset </button>
                                        </div>
                                        
                                        </div> <div class="col-lg-6">
                                       
                                         
                                         <div class="form-group">
                                            <label class="intrate">Smtp Password</label>
                                            <input class="form-control regcom" name="smtp_password" id="smtp_password" value="<?php echo $row->smtp_password; ?>" type="password">
                                        </div>
                                         
                                         <div class="form-group">
                                            <label>Admin :-email</label>
                                            <input class="form-control regcom"  name="email"  id="email"  value="<?php echo $row->email; ?>">
                                           
                                        </div>
                                         <div class="form-group">
                                            <label>Places </label>
                                          <select class="form-control" name="places" id="places">
                                               <option value="google"<?php if($row->places == 'google') echo 'selected'; ?> >Google Map</option>
                                               <option value="default" <?php if($row->places == 'default') echo 'selected'; ?>>Default</option>
                                               
                                                  </select>
                                           
                                        </div>
                                          
                                         <div class="form-group">
                                            <label>Sender ID(sms)</label>
                                            <input class="form-control regcom"  name="sender-id"  id="sender-id"  value="<?php echo $row->sender_id; ?>">
                                           
                                        </div>
                                        <div class="form-group">
                                            <label class="intrate">Sms Username</label>
                                            <input class="form-control regcom" name="sms_username" id="sms_username" value="<?php echo $row->sms_username; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label class="intrate">Sms Password</label>
                                            <input class="form-control regcom" name="sms_password" id="sms_password" value="<?php echo $row->sms_password; ?>" type="password">
                                        </div>
                                         <input class="form-control regcom"  name="id"  id='id'  value="<?php echo $row->id; ?>" type="hidden">
                                        
                                          
                                        
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                              
                               
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url();?>assets/dist/js/sb-admin-2.js"></script>
    
    
    
    
    
    
    
      <!--/column1-->
      <!-- /datepicker -->
      
    
      
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css" />
        <script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     <script type="text/javascript">
$(document).ready(function(){
	
	setTimeout(function(){$("#mess").hide(); }, 3000);					   
						   
						   
$('.regcom').on('change', function (){
																		   var a = $(this).val();
																		   if(a != '') {
																			   $(this).removeClass('error-admin');
																		   } else {
																			    $(this).addClass('error-admin');
																		   }
																			  
																	  });						   
	 			   

	
	function ValidateEmail(email) {
        var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        return expr.test(email);
    };
	
	
$("#taxiadd").click(function(){
 var title = $('#title').val();
      logo = $('#logo').val();
	   url = $('#url').val();
	   user = $('#smtp_username').val();
	   pass = $('#smtp_password').val();
	   host = $('#smtp_host').val();
	   tag =  $('#tag').val();
	   email =   $('#email').val();
	  var pattern = /^\d{10}$/;
	  senderid= $('#sender-id').val();
	  smspass = $('#sms_password').val();
	  smsuser = $('#sms_username').val();
    // only validate going forward. If current group is invalid, do not go further
    // .parsley().validate() returns validation result AND show errors
	
	
    if(!title){
	   
	   $( "#title" ).addClass('error-admin');
	    $("#title").focus();
		return false;
   }
   
   
   if(!logo){
	   
	   alert("Please select a logo");
	    $("#logo").focus();
		return false;
   }
   if(!url){
	   
	   $("#url").addClass('error-admin');
	    $("#url").focus();
		return false;
   }
 if(!tag){
	   
	   $( "#tag" ).addClass('error-admin');
	    $("#tag").focus();
		return false;
   } 
 if(!user){
	   
	   $( "#smtp_username" ).addClass('error-admin');
	    $("#smtp_username").focus();
		return false;
   }
    if(!host){
	   
	   $( "#smtp_host" ).addClass('error-admin');
	    $("#smtp_host").focus();
		return false;
   }
    if(!pass){
	   
	   $( "#smtp_password" ).addClass('error-admin');
	    $("#smtp_password").focus();
		return false;
   }
   
  
 
  
 if(!ValidateEmail(email)){
	   
	   $( "#email" ).addClass('error-admin');
	    $("#email").focus();
		return false;
   }
   if(!senderid){
	   
	   $( "#sender-id" ).addClass('error-admin');
	    $("#sender-id").focus();
		return false;
   }

if(!smsuser){
	   
	   $( "#sms_username" ).addClass('error-admin');
	    $("#sms_username").focus();
		return false;
   }
  if(!smspass){
	   
	   $( "#sms_password" ).addClass('error-admin');
	    $("#sms_password").focus();
		return false;
   }
 
 
 
 

});
});





</script>


</body>

</html>
