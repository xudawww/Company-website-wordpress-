<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="description" content="">
      <meta name="author" content="">
        <?php
	   $query = $this->db->query(" SELECT * FROM `settings` order by id DESC ");
		$row = $query->row('settings');
	  ?>
      <title><?php echo $row->title; ?></title>
      <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">
       <link href='<?php echo base_url();?>assets/css?family=Open+Sans' rel='stylesheet' type='text/css'>
      <!-- Bootstrap core CSS -->
      <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
      <!-- Custom styles for this template -->
      <link href="<?php echo base_url();?>assets/css/jumbotron.css" rel="stylesheet">
       <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
      <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
      <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
         <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script> <!-- Gem jQuery -->
      
      <script src="<?php echo base_url();?>assets/js/ie-emulation-modes-warning.js"></script>
      <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
      
       <link rel="shortcut icon" type="image/icon" href="<?php echo base_url();?>assets/images/favicon.ico"/>
      
      
    <!-- Login -->
    <link href='<?php echo base_url();?>assets/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'> 
 	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/login/style.css"> <!-- Gem style -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/sidebar/component.css"> <!-- Gem style -->
	<script src="<?php echo base_url();?>assets/js/login/modernizr.js"></script> <!-- Modernizr -->
    <script src="<?php echo base_url();?>assets/js/login/main.js"></script> <!-- Gem jQuery -->
    
   
   
   
  
   
   
          <!--/column1-->
      <!-- /container -->
      <!-- Bootstrap core JavaScript
         ================================================== -->
     
      
       


        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
   
   
   
   
   
   
   
   
      
      
   </head>
   <body class="about-us1">
   <ul class="cbp-vimenu" >
              <li><a href="<?php echo base_url();?>" class="icon-logo">Logo</a></li>
                                        
                       <?php  if($username = $this->session->userdata('username')){
		$value = $this->session->userdata('username');
		}else{
		$value= $this->input->cookie('username', false);
		}
						if(!empty($value)){
							?>
                              <li ><a href="<?php echo base_url();?>callmycab/account" class="icon-login sess-login"><?php echo $value; ?> </a></li>
                        <?php
						}else{?>
              <nav class="main-nav">
              <li ><a href="javascript:void(0);" class="icon-login sess-login1">Login/Register </a></li>
              </nav>
             <?php
						}
						?>
              <li><a href="#" class="icon-callback"> Callback</a></li>
              <li><a href="javascript:void(0);" class="icon-freechart parafair" data-toggle="modal" data-target="#myModal"> Farechart</a></li>
              <li><a href="<?php echo base_url();?>callmycab/about" class="icon-about"> About </a></li>
              <li><a href="#" class="icon-contact"> Contact </a></li>
              </ul>
     <div class="jumbotron about-sw">
      
     
         <div class="bnr">
           <?php
	  include"uploads/farechart.php";
	 include"uploads/callmycab_header.php";
	 ?>
     
            <!--/.navbar-collapse -->
         </div>
      </nav>
      <!-- Main jumbotron for a primary marketing message or call to action -->
    
            <div class="container">
            <div class="secssion1">

               
                <!-- My Account -->
               
               
               <div class="col-md-12">
               		<div class="row">
               		<div class="myaccount about">
                    
                    
                    </div>
                    
                    
                    <!--about us-->
                    
                    
                    <div class="aboutus">
                      <div class="img-abt">
                        <div class="col-lg-4">
                        	<div class="bg-about">
                            	<h3 class="head-abt">About Us</h3>
                            </div>
                        </div>
                       </div> 
                       
                       <div class="para-abt">
                       		<p class="para-content">
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.							</p>
                            <p class="para-content">
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.							</p>
                             <h3 class="sub-head"><strong>Lorem Ipsum</strong></h3>
                            <p class="para-content">
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.							</p>
                            <h3 class="sub-head"><strong>Lorem Ipsum</strong></h3>
                            <p class="para-content">
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.							</p>
                            <p class="para-content">
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.							</p>
                            <h3 class="sub-head"><strong>Lorem Ipsum</strong></h3>
                            <p class="para-content">
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.							</p>
                            <p class="para-content">
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.							</p>
                            
                            <ul class="list-para">
                            	<li>
								It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</li>
                                <li>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</li>
                                <li>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</li>
                                <li>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</li>
                                <li>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</li>
                            </ul>
                            
                            <p class="para-content">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
                       </div>
                                                                  
                    </div>
                    
                    
                    <!--/about us-->
                    
                    
                    </div>
               </div>
                    
                    
                    </div>
                    </div>
               </div>
               <!--/My Account--> 
               
               
                 
                  
               </div>
            </div>
         </div>
 
      <!-- column1-->
      <!--/column1-->
      
      
      <!-- column2-->

      <script src="//code.jquery.com/jquery-1.11.2.min.js"></script>
<script src="jquery.simplePagination.js"></script>
      
      
      
  <script type="text/javascript">
  
 
$(document).ready(function(){ 

$('.cancel').click(function(){	
							
	var r = confirm("Are you sure want to cancel the booking ");
	if (r == true) {
	var th=$(this);			
	var id = $(this).attr('title');
	var status = "Cancelled";
	
$.ajax({
url:'<?php echo base_url();?>callmycab/cancel',
type:'post',
data:{'id':id,'status':status},
success:function(cancel){
console.log(cancel);
if(cancel==0){
	
	
alert("err");

}
else{
th.hide();
	location.reload();
}
}
});  								
	}
						   
});						   
						   
						   
						   
						   
	
 
$('.updateuser').click(function(){	
	

var mobile = $('.contact-mobile').val();
var gender = $("input[type='radio'].contact-gender:checked").val();

 var pattern = /^\d{10}$/;
 if(!pattern.test(mobile)){
	   $(".contact-mobile").addClass('required');
	    $(".contact-mobile").focus();
		return false;
   }
if(!gender){
	alert('Please select gender');
	$(".contact-gender").focus();
		return false;
}

								
								
								
var value =$(".contact-form").serialize() ;

$.ajax({
url:'<?php echo base_url();?>callmycab/contact',
type:'post',
data:value,
success:function(contact){
console.log(contact);
if(contact==1){
alert('profile details updated successfully');
}
else{
alert('profile update fail');
}
}
});  
});  
											 
											 
											 
											 
						
	
						
						
						
						
						
											 
											 
											 });
			
	
			
			</script>
    
    
      
      <!--/column1-->
      <!-- /container -->
      <!-- Bootstrap core JavaScript
         ================================================== -->
     <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-timepicker.css"/>
<!-- Load jQuery JS -->
<script src="<?php echo base_url();?>assets/js/jquery-timepicker.js"></script>
<!-- Load jQuery UI Main JS -->
<script src="<?php echo base_url();?>assets/js/jquery-timepicker-min.js"></script>
<!--end timepicker-->

      <!-- Placed at the end of the document so the pages load faster -->
      <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
      <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
      <script src="<?php echo base_url();?>assets/js/ie10-viewport-bug-workaround.js"></script>
      
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css" />
        <script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
       <script type="text/javascript">
	  $(document).ready(function () {
							 
							 $(".datepicker1").datepicker({
														  showOn: 'button',
	     buttonText: 'Show Date',
	     buttonImageOnly: true,
	     buttonImage: '<?php echo base_url();?>assets/images/myaccount_calnder.png'
	  });	  
				
				
		$( ".datepicker" ).datepicker({
																dateFormat : 'dd-mm-yy',
		changeMonth: true,
        changeYear: true,
		yearRange: '1910:2010'
																//this option for allowing user to select from year range
																});	
				
				
				
$('.datepicker1').on('change', function() {
										var status = $('.book-status.active1').find("a").attr('title');
										var date = $('.datepicker1').val();
										$.ajax({
											   url:'<?php echo base_url();?>callmycab/search1',
											   data:{'date' : date,'status' : status},
											   type:'post',
											   success:function(result){
												   //alert(result);
												   $(".table").html(result);
												   }	
											});
});					   
$('.book-status').click(function(){	
					var status = $(this).find("a").attr('title');
					
					$('.book-status').removeClass('active1');
					var date = $('.datepicker1').val();
					$(this).addClass('active1');
					$.ajax({
						   url:'<?php echo base_url();?>callmycab/search1',
						   data:{'date':date,'status':status},
						   type:'post',
						   success:function(result){
							  //alert(result);
							 // alert(status);
							   //alert(date);
							   $(".table").html(result);
							   }	
							   });				  
});							   
$("#example").simplePagination({

// the number of rows to show per page
perPage: 5,

// CSS classes to custom the pagination
containerClass: '',
previousButtonClass: '',
nextButtonClass: '',

// text for next and prev buttons
previousButtonText: 'Previous',
nextButtonText: 'Next',

// initial page
currentPage: 1

});		
	
});
	  </script>
      
      
   </body>
</html>
