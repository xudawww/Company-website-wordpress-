<?php
ob_start();
if($username = $this->session->userdata('username') || $this->input->cookie('username', false)){
?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="description" content="">
      <meta name="author" content="">
        <?php
	   $query = $this->db->query(" SELECT * FROM `settings` order by id DESC ");
		$row = $query->row('settings');
	  ?>
      <title><?php echo $row->title; ?></title>
      <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">
       <link href='<?php echo base_url();?>assets/css?family=Open+Sans' rel='stylesheet' type='text/css'>
      <!-- Bootstrap core CSS -->
      <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
      <!-- Custom styles for this template -->
      <link href="<?php echo base_url();?>assets/css/jumbotron.css" rel="stylesheet">
       <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
      <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
      <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
         <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script> <!-- Gem jQuery -->
      
      <script src="<?php echo base_url();?>assets/js/ie-emulation-modes-warning.js"></script>
      <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
      
       <link rel="shortcut icon" type="image/icon" href="<?php echo base_url();?>assets/images/favicon.ico"/>
      
      
    <!-- Login -->
    <link href='<?php echo base_url();?>assets/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'> 
 	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/login/style.css"> <!-- Gem style -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/sidebar/component.css"> <!-- Gem style -->
	<script src="<?php echo base_url();?>assets/js/login/modernizr.js"></script> <!-- Modernizr -->
    <script src="<?php echo base_url();?>assets/js/login/main.js"></script> <!-- Gem jQuery -->
    
   
   
   
   <?php
    include"uploads/farechart.php"; 
   ?>
   
   
          <!--/column1-->
      <!-- /container -->
      <!-- Bootstrap core JavaScript
         ================================================== -->
     
      
       


        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
   
   
   
   
   
   
   
   
      
      
   </head>
   <body>
   <ul class="cbp-vimenu">
              <li><a href="<?php echo base_url();?>" class="icon-logo">Logo</a></li>
                     
            
              <li><a href="javascript:void(0);" class="icon-freechart parafair" data-toggle="modal" data-target="#myModal">Farechart</a></li>
              <li><a href="#" class="icon-about"> About </a></li>
                                
                       <?php  if($username = $this->session->userdata('username')){
		$value = $this->session->userdata('username');
		}else{
		$value= $this->input->cookie('username', false);
		}
						if(!empty($value)){
							?>
                              <li ><a href="<?php echo base_url();?>callmycab/logout" class="icon-logout ">Logout </a></li>
                        <?php
						}else{?>
              <nav class="main-nav">
              <li ><a href="javascript:void(0);" class="icon-login sess-login1">Login/Register </a></li>
              </nav>
             <?php
						}
						?>
              </ul>
     <div class="jumbotron">
      
     
         <div class="bnr">
          <?php
		
	 include"uploads/myaccount_header.php";
	 ?>
     
            <!--/.navbar-collapse -->
         </div>
      </nav>
      <!-- Main jumbotron for a primary marketing message or call to action -->
    
            <div class="container">
            <div class="secssion1">

               
                <!-- My Account -->
               <div class="col-md-12">
               		<div class="row">
               		<div class="myaccount">
                    
                    <div class="col-md-4"> 
                   	<div class="profile_outr">
                    	<div class="myacunt_hd">
                        
                        	<div class="prfl_hd1">
                            	<div class="profl_img"> <img src="<?php echo base_url();?>assets/images/profile_pic.jpg" alt=""> </div> <h1> PROFILE </h1> <p> Personal Details </p>  
                            
                            
                            </div>
                            <nav class="main-nav1">
                            <div class="prfl_hd2">  Change Password</div> 
                            </nav>
                        
                        </div>
                        
                        <div class="myacunt_area">
                        
         <?php
		 if($this->session->userdata('username')){
		$username=$this->session->userdata('username');
		}else{
			$username= $this->input->cookie('username', false);
		}
		 
		 $query = $this->db->query("SELECT * FROM  userdetails WHERE username='$username'");
		$row = $query->row('userdetails');
		 ?>

                        <form method="post" class="contact-form">
                        
                        <h1> Contact Information </h1>
                        <p class="field_hd"> Name </p>
                        <input type="text" placeholder="Starting " name="username" class="field_myacnt readonly" value="<?php echo $row->username; ?>" readonly>
                        
                        <p class="field_hd"> Mobile Number </p>
                        <input type="text" placeholder="Starting" name="mobile" class="field_myacnt contact-mobile readonly" value="<?php echo $row->mobile; ?>" readonly>
                        
                        <p class="field_hd"> Email </p>
                        <input type="text" placeholder="Starting" name="email" class="field_myacnt contact-email readonly" value="<?php echo $row->email; ?>"readonly>
                        
                        
                        <h1> Basic Information </h1>
                        <p class="field_hd"> Gender </p>
                        <div class="field_radio">
                        <input type="radio" name="gender" class="field_radio contact-gender" value="male"  <?php if($row->gender=='male') {echo "checked";} ?>/> Male
						<input type="radio" name="gender" class="field_radio contact-gender" value="female"  <?php if($row->gender=='female'){echo "checked";} ?>/> Female 
 <p class="text-gender"><br></p>
                        </div>
                        
                        <p class="field_hd"> Date of Birth </p>
                        <input type="text" placeholder="DD/MM/YYYY" name="dob" class="field_myacnt datepicker regcom" readonly value="<?php echo $row->dob; ?>" >
                        
                        <p class="field_hd"> Anniversary Date </p>
                        <input type="text" placeholder="DD/MM/YYYY" name="anniversary_date" readonly class="field_myacnt datepicker regcom" value="<?php echo $row->anniversary_date; ?>">
                        
                        <input type="button" class="updatebtn updateuser" value="Update">
                      
                       <a href="#"> <div class="cancelbtn"> Cancel </div></a>
                      
                        </form>
                       
                        </div>
                        
                       
                    </div>
                    </div>
                    
                    
                    
                    <div class="col-md-8"> 
                    <div class="booking_outr">
                    
                    <div class="booking_hd"> 
                   <!--  /* <div class="bkng_cl1"> <h1> BOOKING DETAILS </h1>
                        <ul class="tab-links">
                         <li class="book-status active">
                           <a href="#" title='Booking'>Active</a>
                         </li>
                         <li class="book-status">
                            <a href="#" title='Cancelled'>Past</a>
                         </li>
                         </ul>*/-->
                         
                         
                       <!--  </div>
                        <div class="bkng_cl2"> <input type="text" placeholder="" name="searchdate" class="field-srch datepicker1"> </div>
                        <div class="bkng_cl3"></div>-->
                    
                   <div class="bkng_cl1"> <h1> BOOKING DETAILS </h1> </div>
                     <div class="bkng_cl2">   <div class="my_actv book-status active1"> <a href="#" title='Booking'> Active</a> </div>  <div class="my_past book-status "> <a href="#" title='Cancelled'>Past</a> </div></div>
                     <div class="bkng_cl3"><input type="text"  name="searchdate" placeholder="" class=" field-srch  datepicker1">
                     </div>
                     
                    
                    </div>
                    <div class="table">
                    <div class="booking_area">
                    
                    <!-- Box 1 -->
                    <?php
					
					 if(!$results) {
						 
		echo "<div><p style='font-family:sans-serif;font-size:15px;margin-top:12px;text-align:center;'>You don't have any bookings with us. Do you want to book a taxi?</p><div style='text-align:center;'>"; ?>
		<a class='btn-now' href='<?php echo base_url();?>'>Book Now</a></div></div>
		<?php
	}else{
					 foreach($results as $row1) {
						 
					?>
                    	<div class="bkng_darea">
                        <div class="bkng_darea_hd">
                        <div class="row">
                            <div class="col-md-7"> <div class=" bkng_rtfrm"> <?php if($row1->pickup_area){ echo $row1->pickup_area; }else{ echo $row1->pickup_address;}?> </div> <?php echo $row1->drop_area ;?> </div>     
                            <?php if($row1->status=='Booking'){?>
                            <div class="col-md-5">
                            
                            <div class="bkng_hd_icon"> <a href="#"> <img src="<?php echo base_url();?>assets/images/track.png" alt="">  Track </a> </div>
                            <div class="bkng_hd_icon"> <a href="<?php if($row1->status=='Booking'){?><?php echo base_url();?>callmycab/edit_booking?id=<?php echo $row1->id; }?>"><img src="<?php echo base_url();?>assets/images/edit.png" alt=""> Edit </a> </div>
                            <div class="bkng_hd_icon"> <a href="javascript:void(0);" class="cancel"  title="<?php echo $row1->id;?>" ><img src="<?php echo base_url();?>assets/images/cancel.png" alt=""> Cancel </a> </div>
                            </div>
                            <?php }
					
							?>
                            </div>
                            </div>
                            
                            <div class="row">
                            
                            <div class="bkng_darea_listmain">
                            <div class="col-md-2"> <div class="bkng_darea_list"><?php $date = $row1->pickup_date;
							echo date('D, d M',strtotime($date));?><br>

							<?php echo $row1->pickup_time;?> </div> </div>
                            <div class="col-md-3"> <div class="bkng_darea_list"> <?php echo $row1->uneaque_id;?> <p> BOOKING ID </p></div> </div>
                            <div class="col-md-3"> <div class="bkng_darea_list"> <?php echo $row1->taxi_type;?> <p> Car Type </p> </div> </div>
                            <div class="col-md-2">  <div class="bkng_darea_list">&#8377; <?php echo $row1->amount;?> <p> Total Fare </p> </div> </div>
                            <div class="col-md-2"> <div class="bkng_darea_list bkng_bdrnone"> <?php echo $row1->status;?>. </div> </div>
                        </div>
                        </div>
                        </div>
                    <!-- End Box 1 -->
                    <?php
					 }
	}
					 ?>


<nav>
  
  <?php echo $this->pagination->create_links(); ?>
</nav>



</div>





































         
         
          
           
		




























































                    
                    </div>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    </div>
                    
                    
                    
                    </div> 
                    </div>
                    
                    
                    </div>
                    </div>
               </div>
               <!--/My Account--> 
               
               
                 
                  
               </div>
            </div>
         </div>
 
      <!-- column1-->
      <!--/column1-->
      
      
      <!-- column2-->

      
      
      
      
  <script type="text/javascript">
  
 
$(document).ready(function(){ 

$('.cancel').click(function(){	
							
	var r = confirm("Are you sure want to cancel the booking ");
	if (r == true) {
	var th=$(this);			
	var id = $(this).attr('title');
	var status = "Cancelled";
	
$.ajax({
url:'<?php echo base_url();?>callmycab/cancel',
type:'post',
data:{'id':id,'status':status},
success:function(cancel){
console.log(cancel);
if(cancel==0){
	
	
alert("err");

}
else{
th.hide();
	location.reload();
}
}
});  								
	}
						   
});						   
						   
						   
						   
						   
	
 
$('.updateuser').click(function(){	
	

var mobile = $('.contact-mobile').val();
var gender = $("input[type='radio'].contact-gender:checked").val();

 var pattern = /^\d{10}$/;
 if(!pattern.test(mobile)){
	   $(".contact-mobile").addClass('required');
	    $(".contact-mobile").focus();
		return false;
   }
if(!gender){
	alert('Please select gender');
	$(".contact-gender").focus();
		return false;
}

								
								
								
var value =$(".contact-form").serialize() ;

$.ajax({
url:'<?php echo base_url();?>callmycab/contact',
type:'post',
data:value,
success:function(contact){
console.log(contact);
if(contact==1){
alert('profile details updated successfully');
}
else{
alert('profile update fail');
}
}
});  
});  
											 
											 
											 
											 
						
	
						
						
						
						
						
											 
											 
											 });
			
	
			
			</script>
    
    
      
      <!--/column1-->
      <!-- /container -->
      <!-- Bootstrap core JavaScript
         ================================================== -->
     <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-timepicker.css"/>
<!-- Load jQuery JS -->
<script src="<?php echo base_url();?>assets/js/jquery-timepicker.js"></script>
<!-- Load jQuery UI Main JS -->
<script src="<?php echo base_url();?>assets/js/jquery-timepicker-min.js"></script>
<!--end timepicker-->

      <!-- Placed at the end of the document so the pages load faster -->
      <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
      <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
      <script src="<?php echo base_url();?>assets/js/ie10-viewport-bug-workaround.js"></script>
      
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css" />
        <script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
       <script type="text/javascript">
	  $(document).ready(function () {
							 
							 $(".datepicker1").datepicker({
														  showOn: 'button',
	     buttonText: 'Show Date',
	     buttonImageOnly: true,
	     buttonImage: '<?php echo base_url();?>assets/images/myaccount_calnder.png'
	  });	  
				
				
		$( ".datepicker" ).datepicker({
																dateFormat : 'dd-mm-yy',
		changeMonth: true,
        changeYear: true,
		yearRange: '1910:2010'
																//this option for allowing user to select from year range
																});	
				
				
				
$('.datepicker1').on('change', function() {
										var status = $('.book-status.active1').find("a").attr('title');
										var date = $('.datepicker1').val();
										$.ajax({
											   url:'<?php echo base_url();?>callmycab/search1',
											   data:{'date' : date,'status' : status},
											   type:'post',
											   success:function(result){
												   //alert(result);
												   $(".table").html(result);
												   }	
											});
});					   
$('.book-status').click(function(){	
					var status = $(this).find("a").attr('title');
					
					$('.book-status').removeClass('active1');
					var date = $('.datepicker1').val();
					$(this).addClass('active1');
					$.ajax({
						   url:'<?php echo base_url();?>callmycab/search1',
						   data:{'date':date,'status':status},
						   type:'post',
						   success:function(result){
							  //alert(result);
							 // alert(status);
							   //alert(date);
							   $(".table").html(result);
							   }	
							   });				  
});							   
		
	
});
	  </script>
      
      
   </body>
</html>
<?php
}else{
	 redirect('/', 'refresh');
}

?>