!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url();?>assets/dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="<?php echo base_url();?>assets/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php
	 include"uploads/admin_header.php";
	 ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> Edit Point to Point Transfer</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         Edit Point to Point Transfer
                           <div class="editbook"></div>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                <?php
								$id = $_GET['id3'];
						  
		 $query = $this->db->query("SELECT * FROM  bookingdetails WHERE  id ='$id'");
		 $row = $query->row('bookingdetails');
								?>
                                    <form role="form"  method="post" id="point_reg">
                                        
                                       
                                        <div class="form-group">
                                            <label>Pickup Area</label>
                                           <input class="form-control regcom"  name="pickup_area" value="<?php echo $row->pickup_area; ?>" readonly>
                                        </div>
                                         <div class="form-group">
                                            <label>Drop Area</label>
                                           <input class="form-control regcom" name="drop_area"  value="<?php echo $row->drop_area; ?>" readonly>
                                        </div>
                                        
                                         
                                         
                                         <div class="form-group">
                                            <label>Pickup Date</label>
                                            <input class="form-control regcom"  name="pickup_date"  value="<?php echo $row->pickup_date; ?>" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label>Pickup Time</label>
                                            <input class="form-control regcom"  name="pickup_time"   value="<?php echo $row->pickup_time; ?>" readonly>
                                            
                                        </div>
                                        
                                         <div class="form-group">
                                            <label>Car Type </label>
                                            <input class="form-control " name="taxi_type" value="<?php echo $row->taxi_type; ?>" readonly>
                                           
                                        </div>
                                        <div class="form-group">
                                            <label>Area</label>
                                            <input class="form-control " name="area" value="<?php echo $row->area; ?>" readonly>
                                            
                                        </div>
                                        <div class="form-group">
                                        <input type="button" class="btn btn-primary" value="Save Details "  name="Save" id="pointedit">
                                        
                                        </div>
                                        </div>  <div class="col-lg-6">
                                         
                                         <div class="form-group">
                                            <label>Landmark</label>
                                            <input class="form-control " name="landmark" value="<?php echo $row->landmark; ?>" readonly>
                                            
                                        </div>
                                         <div class="form-group">
                                            <label>Pickup Address</label>
                                            <input class="form-control" name="pickup_address" value="<?php echo $row->pickup_address; ?>" readonly>
                                            
                                        </div>
                                         <div class="form-group">
                                            <label>Promo Code</label>
                                            <input class="form-control " name="promo_code" value="<?php echo $row->promo_code; ?>" readonly>
                                            
                                        </div>
                                        <div class="form-group">
                                            <label>Distance</label>
                                            <input class="form-control" name="distance" value="<?php echo $row->distance; ?>" id="distance">
                                            
                                        </div>
                                        <div class="form-group">
                                            <label>Amount</label>
                                            <input class="form-control"  name="amount" value="<?php echo $row->amount; ?>" id="amount">
                                            <input class="form-control"  name="id" type="hidden" value="<?php echo $row->id; ?>">
                                        </div>
                                         <div class="form-group">
                                            <label>Assigned For</label>
                                            <select id="cartype" class="form-control regcom" name="assigned_for">
                                            <?php
											$query1 = $this->db->query("SELECT * FROM  driver_details ");
											 foreach($query1->result_array('driver_details') as $row1){
												?><option value="<?php  echo $row1['name'];?>"><?php  echo $row1['name']; ?></option><?php
											 }
											?>
                                            </select>
                                        </div>
                                       
                                      
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                              
                               
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url();?>assets/dist/js/sb-admin-2.js"></script>
    
    
    
    
    
    
    
      <!--/column1-->
      <!-- /datepicker -->
      
    
      
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css" />
        <script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     <script type="text/javascript">
$(document).ready(function(){
		   
 $('#distance').bind('keypress', function(e) { 
return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
  });
	 $('#amount').bind('keypress', function(e) { 
return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
  });							   

$("#pointedit").click(function(){
 
 
 var value =$("#point_reg").serialize() ;

$.ajax({
url:'<?php echo base_url();?>admin/update_point',
type:'post',
data:value,
success:function(res){
	$(".editbook").show();
console.log(res);
if(res==1){
		$(".editbook").html('<p class="success">Update Successfully</p>');
	setTimeout(function(){$(".editbook").hide(); }, 1500);
	//window.location.href="<?php echo base_url();?>index.php/admin/pointview";
}
else{

	
	
	
	
$(".editbook").html('<p class="error">Errorr </p>');
setTimeout(function(){$(".editbook").hide(); }, 1500);
}
}
});
});
});





</script>


</body>

</html>
