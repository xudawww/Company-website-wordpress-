
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url();?>assets/dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="<?php echo base_url();?>assets/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php
	 include"uploads/admin_header.php";
	 ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> Add New Role</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                       Role 
                        <div class="result-role"></div>
                        <div class="adminuser1"></div>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                   <form method="post" class="form parsley-form col-sm-12" data-validate="parsley">

<div style="width:100%; float:left; clear:both; margin-bottom:25px">
<div class="pull-left">
<div class="btn-group" style="clear:both">
<input type="hidden" value="<?php if(isset($_GET['role'])){ echo $_GET['role'];} ?>" id="get_role_id"/>
<?php
$roles =  $this->db->query("SELECT * FROM  role");
 foreach($roles->result_array('role') as $role){
	 ?>
    <button class="btn btn-default <?php if(isset($_GET['role'])) { if($_GET['role']== $role['r_id']) { echo "active";}} ?>" type="button" style="text-transform:capitalize" onClick="location.href='<?php echo base_url();?>admin/role_management?role=<?php echo  $role['r_id'];?>'"><?php echo  $role['rolename'];?></button>
    
<?php
}?> 
</div>
<div style="margin:10px; margin-bottom:0; clear:both;">
<a href="#"  data-toggle="modal" data-target="#myModal">Add Role</a> 
<a href="#"  data-toggle="modal" data-target="#myModal1" style="margin-left:25px;">Delete Role</a> 
</div>
</div>
<?php
// role based displayed
if(!isset($_GET['role']) || ($_GET['role']== "1") ) {
/*if(isset($_GET['role'])) {
	if($_GET['role'] == "1") {*/
		?>
        <div class="col-sm-12">
        <div class="jumbotron admin-page">
        <p> All page are accessible </p>
        </div>
        </div>
        
        <?php
	} else {
		
		            $d = $_GET['role'];
		$check_role = $this->db->query("select * from role where r_id ='$d' ");
		if($check_role->num_rows == 0) {
			$this->load->view('role-management');
		}
		$d = $_GET['role'];
		 
		$role_id= $this->db->query("select * from role_permission where role_id ='$d' ");
		if($role_id->num_rows == 1) {
			foreach($role_id->result_array() as $result){
			
			$str = rtrim($result['page_id'],',');
			$p = explode(',', $str);
			
			?>
			
             <div class="col-sm-8 admin-roleman">
        <!--<label>Default</label>
       -->
        <!--<div class="checkbox"><label><input  class="role_checkbox" type="checkbox" checked disabled value="1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21">Basic User Needs</label></div>-->
        <label>Booking Details</label>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("15", $p)) { echo "checked";} ?> type="checkbox" value="15">Point to Point Transfer  </label></div>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("10", $p)) { echo "checked";} ?> type="checkbox" value="10">Airport Transfer </label></div>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("13", $p)) { echo "checked";} ?> type="checkbox" value="13">Hourly Rental Transfer </label></div>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("14", $p)) { echo "checked";} ?> type="checkbox" value="14">Outstation Transfer </label></div>
        <label>Promocode Management</label>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("32", $p)) { echo "checked";} ?> type="checkbox" value="32">View Promocode Details  </label></div>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("2", $p)) { echo "checked";} ?> type="checkbox" value="2">Add Promocode </label></div>
        
        <label>Taxi Details</label>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("28", $p)) { echo "checked";} ?> type="checkbox" value="28">Point to Point Transfer  </label></div>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("27", $p)) { echo "checked";} ?> type="checkbox" value="27">Airport Transfer </label></div>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("29", $p)) { echo "checked";} ?> type="checkbox" value="29">Hourly Rental Transfer </label></div>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("30", $p)) { echo "checked";} ?> type="checkbox" value="30">Outstation Transfer </label></div>
         
         <label>Driver Management</label>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("31", $p)) { echo "checked";} ?> type="checkbox" value="31">View Driver Details  </label></div>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("3", $p)) { echo "checked";} ?> type="checkbox" value="3">Add Driver Details </label></div>
         <label>Settings</label>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("4", $p)) { echo "checked";} ?> type="checkbox" value="4">Add Settings  </label></div>
        <label>Role Management</label>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("26", $p)) { echo "checked";} ?> type="checkbox" value="26">Add Role Permission  </label></div>
        
         <label>Backend User</label>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("33", $p)) { echo "checked";} ?> type="checkbox" value="33">view User Details  </label></div>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("34", $p)) { echo "checked";} ?> type="checkbox" value="34">Add User Details  </label></div>
        <div class="checkbox"><label><input class="role_checkbox" <?php if(in_array("35", $p)) { echo "checked";} ?> type="checkbox" value="35">Edit User Details  </label></div>
        
        <input type="hidden" name="role_permission" class="role_permission1" id="role_permission" value="<?php echo $result['page_id']; ?>"/>
         <input class="btn  btn-secondary role-sub"  type="button" name="role" id="submit" value="Submit"/>
        </div>
            <?php
			}
		} else {
		?>
        <div class="col-sm-8">
        <!--<label>Default</label>-->
      <!--  <div class="checkbox"><label><input  class="role_checkbox" type="checkbox" checked disabled value="1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21">Basic User Needs</label></div>-->
       <label>Booking Details</label>
        <div class="checkbox"><label><input class="role_checkbox" type="checkbox" value="15">Point to Point Transfer  </label></div>
        <div class="checkbox"><label><input class="role_checkbox"  type="checkbox" value="10">Airport Transfer </label></div>
        <div class="checkbox"><label><input class="role_checkbox"  type="checkbox" value="13">Hourly Rental Transfer </label></div>
        <div class="checkbox"><label><input class="role_checkbox" type="checkbox" value="14">Outstation Transfer </label></div>
        
        <label>Promocode Management</label>
        <div class="checkbox"><label><input class="role_checkbox" type="checkbox" value="32">View Promocode Details  </label></div>
        <div class="checkbox"><label><input class="role_checkbox" type="checkbox" value="2">Add Promocode </label></div>
        
        <label>Taxi Details</label>
        <div class="checkbox"><label><input class="role_checkbox"  type="checkbox" value="28">Point to Point Transfer  </label></div>
        <div class="checkbox"><label><input class="role_checkbox"  type="checkbox" value="27">Airport Transfer </label></div>
        <div class="checkbox"><label><input class="role_checkbox"  type="checkbox" value="29">Hourly Rental Transfer </label></div>
        <div class="checkbox"><label><input class="role_checkbox"  type="checkbox" value="30">Outstation Transfer </label></div>
        
          <label>Driver Management</label>
        <div class="checkbox"><label><input class="role_checkbox" type="checkbox" value="31">View Driver Details  </label></div>
        <div class="checkbox"><label><input class="role_checkbox"  type="checkbox" value="3">Add Driver Details </label></div>
        
         <label>Settings</label>
        <div class="checkbox"><label><input class="role_checkbox" type="checkbox" value="4">Add Settings  </label></div>
        <label>Role Management</label>
        <div class="checkbox"><label><input class="role_checkbox" type="checkbox" value="26">Add Role Permission  </label></div>
        
        <label>Backend User</label>
        <div class="checkbox"><label><input class="role_checkbox"  type="checkbox" value="33">view User Details  </label></div>
        <div class="checkbox"><label><input class="role_checkbox" type="checkbox" value="34">Add User Details  </label></div>
        <div class="checkbox"><label><input class="role_checkbox"  type="checkbox" value="35">Edit User Details  </label></div>
        
       
        <input type="hidden" name="role_permission" class="role_permission1" id="role_permission" value="1,2"/>
         <input class="btn  btn-secondary role-sub"  type="button" name="role" id="submit" value="Submit"/>
        </div>
        <?php }
		?>
        <div class="col-sm-4">
        
        </div>
        <?php
}
?>

</form>

                                </div>
                                <!-- /.col-lg-6 (nested) -->
                              
                               
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->






<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Add New Role</h4>
      </div>
      <form id="validate-basic" action="#" data-validate="parsley" class="form parsley-form">
      <div class="modal-body">
        
        <div class="form-group">
                  <label for="name">Rolename</label>
                  <input type="text" id="rolename" name="name" class="form-control" data-required="true" >
                  
         </div>
         <div class="alert alert-success" id="rolerply" style="display:none;"></div>
         <div id="emptyerr" class="alert alert-danger" style="display:none">Please enter rolename</div>
         
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default rload" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="addrole">Add Role</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal -->





<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Delete Role</h4>
      </div>
      <form id="validate-basic" action="#" data-validate="parsley" class="form parsley-form">
      <div class="modal-body">
      
        <div class="form-group">  
             <label for="name">Rolename</label>
                  <select data-required="true" class="form-control parsley-validated" name="validateSelect" id="deleterolename">
                    <option value="" selected>Please Select</option>
                    <?php $dr =$this->db->query("select * from role ");
					if($dr->num_rows > 0) {
				foreach($dr->result_array() as $row){
						?>
                        <option value="<?php echo $row['rolename']; ?>"><?php echo $row['rolename']; ?></option>
                        <?php
					}
					}
					?>
                  </select>
         </div>
         <div class="alert alert-success" id="drolerply" style="display:none;"></div>
         <div id="emptyerr1" class="alert alert-danger" style="display:none">Please select rolename</div>
         
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default rload" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="deleterole">Delete Role</button>
      </div>
      </form>
    </div>
  </div>
</div>









    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url();?>assets/dist/js/sb-admin-2.js"></script>
    
    
    
    
    
    
    
      <!--/column1-->
      <!-- /datepicker -->
      
    
      
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css" />
        <script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   

 
 
 
  <script type="text/javascript">
  
  $(document).ready(function () {
	    var t='';
	/* Get the checkboxes values based on the class attached to each check box */
	$(".role_checkbox").click(function() {
		$(".role_checkbox:checked").each(function() {
			t+=$(this).val()+',';
			//$('.role_permission').val($(this).val());
		});	
		var input = $('#role_permission');
		input.val(t);
		//alert(t);
		t='';
	});
	
	$('#addrole').click(function(){
		if ($('#rolename').val().length == 0){
			$('#emptyerr').slideToggle(500);
			$('#emptyerr').fadeOut(5000);
		} else {
			var rolename = $('#rolename').val();
			$.ajax({
				type: "POST",
			    url:'<?php echo base_url();?>admin/add_role',
				data:{'rolename':rolename},
                success:function(result){
					
                        console.log(result);
						
                     $("#rolerply").html(result);
					$('#rolerply').slideToggle(500);
					$('#rolerply').fadeOut(5000);
                    }
						
				
				
			});
		}
	});
	
	
	$('#deleterole').click(function(){
		if ($('#deleterolename').val().length == 0){
			$('#emptyerr1').slideToggle(500);
			$('#emptyerr1').fadeOut(5000);
		} else {
			var rolename = $('#deleterolename').val();
			$.ajax({
				type: "POST",
				url: "<?php echo base_url();?>admin/role_delete",
				data: {'rolename':rolename},
				cache: false,
				success: function(result)
				{
					  console.log(result);
					$("#drolerply").html(result);
					$('#drolerply').slideToggle(500);
					$('#drolerply').fadeOut(5000);
				}
			});
		}
	});
	$('.rload').click(function(){
		window.location.reload();
	});
	
	
	$('.role-sub').click(function(){
		  var role_id = $('#get_role_id').val();
		     page_id = $('.role_permission1').val();
			 
		  $.ajax({
url:'<?php echo base_url();?>admin/update_role',
type:'post',
data:{'role_id':role_id,'page_id':page_id},
success:function(book){
	$(".result-role").show();
console.log(book);
if(book==2 || book ==4){
$(".result-role").html('<p class="error">Error</p>');
	//setTimeout(function(){$(".result-role").hide(); }, 3000);
}else if(book == 1){
	$(".result-role").html('<p class="success">Role Permission Added successfully</p>');
//setTimeout(function(){$(".result-role").hide(); }, 1500);

}else{
	$(".result-role").html('<p class="success">Role Permission Changes successfully</p>');
//setTimeout(function(){$(".result-role").hide(); }, 1500);

}

	}
		});  
		 }); 
});
</script>

</body>

</html>
