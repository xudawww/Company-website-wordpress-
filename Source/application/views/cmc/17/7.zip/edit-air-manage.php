
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url();?>assets/dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="<?php echo base_url();?>assets/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php
	 include"uploads/admin_header.php";
	 ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Airport Details</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                        Edit Airport Details
                         <div class="promo-add"></div>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                               <?php
							  $id = $_GET['id'];
						  
		 $query = $this->db->query("SELECT * FROM  airport_details WHERE  id ='$id'");
		 $row = $query->row(' airport_details');
							   ?>
                                     <form role="form"  method="post" id="promocode_reg">
                                        
                                       
                                        <div class="form-group">
                                            <label>Airport </label>
                                           <input class="form-control regcom" value="<?php echo $row->name ?>" name="name" >
                                           <input type="hidden" name='id' value="<?php echo $row->id ?>">
                                        </div>
                                         
                                        <div class="form-group">
                                        <input type="button" class="btn btn-primary" value="Save Details"  name="Save" id="promoedit">
                                       
                                        
                                        </div>
                                      
                                        
                                        
                                    </form>

                                </div>
                                <!-- /.col-lg-6 (nested) -->
                              
                               
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url();?>assets/dist/js/sb-admin-2.js"></script>
    
    
    
    
    
    
    
  
      <!--/column1-->
      <!-- /datepicker -->
      
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery.datetimepicker.css"/>
<!-- Load jQuery JS -->
<script src="<?php echo base_url();?>assets/js/jquery.datetimepicker.js"></script>
<!-- Load jQuery UI Main JS -->

        <script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     <script type="text/javascript">
$(document).ready(function(){
	
	 
	$("#promoedit").click(function(){
 
 
 var value =$("#promocode_reg").serialize() ;

$.ajax({
url:'<?php echo base_url();?>admin/update_airmanage',
type:'post',
data:value,
success:function(res){
	$(".promo-add").show();
console.log(res);
if(res==1){
		$(".promo-add").html('<p class="success">Airport Details Saved Successfully</p>');
	setTimeout(function(){$(".promo-add").hide(); }, 1500);
	//window.location.href="<?php echo base_url();?>index.php/admin/pointview";
}
else{

	
	
	
	
$(".promo-add").html('<p class="error">Errorr </p>');
setTimeout(function(){$(".promo-add").hide(); }, 1500);
}
}
});
});
});





</script>


</body>

</html>
