
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url();?>assets/dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="<?php echo base_url();?>assets/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php
	 include"uploads/admin_header.php";
	 ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"> Add Taxi Details</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                        Add Taxi Details
                        <div class="taxi"></div>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form"  method="post" id="taxi-hourly">
                                        
                                       
                                         <div class="form-group">
                                            <label>Car Type</label>
                                           <select class="form-control regcom" id="cartype" name="cartype">
                                              <option value="Nano">Nano</option>
                                              <option value="Sedan">Sedan</option>
                                              <option value="Tata Indica AC">Tata Indica AC</option>
                                               <option value="Hatchback">Hatchback</option>
                                               <option value="SUV">SUV</option>
                                             
                                                 </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Time</label>
                                           <select class="form-control regcom" id="timetype" name="timetype">
                                            
                                              <option value="day">Day(6:00AM-10:00PM)</option>
                                              <option value="night">Night(10:00PM-6:00AM)</option>
                                              
                                                 </select>
                                        </div>
                                       
                                         <div class="form-group">
                                            <label>Intial Km</label>
                                            <input class="form-control regcom" placeholder="1" name="intialkm"  id="intialkm2">
                                            <input  id="transfertype" name="transfertype" type="hidden" value="Hourly Rental">
                                        </div>
                                      
                                       <div class="form-group">
                                       
                                        <input type="button" class="btn btn-primary" value="Submit "  name="Save" id="taxiadd">
                                        <button type="reset" class="btn btn-primary">Reset </button>
                                        </div>
                                        </div> <div class="col-lg-6">
                                         <div class="form-group">
                                            <label class="intrate">Intial Km Rate</label>
                                            <input class="form-control regcom" placeholder="49" name="intailrate" id="intailrate">
                                        </div>
                                         <div class="form-group">
                                            <label>Rate for Extra Hour</label>
                                            <input class="form-control regcom" placeholder="145" name="extrahour"  id="extrahour">
                                           
                                        </div>
                                        <div class="form-group">
                                            <label>Rate for Extra Km</label>
                                            <input class="form-control regcom" placeholder="145" name="extrakm"  id="extrakm">
                                           
                                        </div>
                                        
                                          </div>
                                        
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                              
                               
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url();?>assets/dist/js/sb-admin-2.js"></script>
    
    
    
    
    
    
    
      <!--/column1-->
      <!-- /datepicker -->
      
    
      
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css" />
        <script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     <script type="text/javascript">
$(document).ready(function(){
	
	$('#intialkm2').on('change', function (){
																		   var a = $(this).val();
																		   $('.intrate').html('Intial '  +  a +' Km Rate');
																		   
																			  
																	  });						   
						   
						   
$('.regcom').on('change', function (){
																		   var a = $(this).val();
																		   if(a != '') {
																			   $(this).removeClass('error-admin');
																		   } else {
																			    $(this).addClass('error-admin');
																		   }
																			  
																	  });						   
	 			   

	 $('#intialkm2').bind('keypress', function(e) { 
return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
  });
	 $('#intailrate').bind('keypress', function(e) { 
return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
  });
	 $('#standardrate').bind('keypress', function(e) { 
return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
  });
	  $('#extrahour').bind('keypress', function(e) { 
return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
  });
	 $('#extrakm').bind('keypress', function(e) { 
return ( e.which!=8 && e.which!=0 && (e.which<48 || e.which>57)) ? false : true ;
  });
	
	
$("#taxiadd").click(function(){
						
 var intialkm2 = $('#intialkm2').val();
      intailrate =  $('#intailrate').val();
	  
	   extrahour =  $('#extrahour').val();
	   extrakm =  $('#extrakm').val();
	
    // only validate going forward. If current group is invalid, do not go further
    // .parsley().validate() returns validation result AND show errors
	
	
	
    if(!intialkm2){
	   
	   $( "#intialkm2" ).addClass('error-admin');
	    $("#intialkm2").focus();
		return false;
   }
   
   
   if(!intailrate){
	   
	   $( "#intailrate" ).addClass('error-admin');
	    $("#intailrate").focus();
		return false;
   }
   
    if(!extrahour){
	   
	   $( "#extrahour" ).addClass('error-admin');
	    $("#extrahour").focus();
		return false;
   }
   if(!extrakm){
	   
	   $( "#extrakm" ).addClass('error-admin');
	    $("#extrakm").focus();
		return false;
   }
  


 
 
 
 
 
 var value =$("#taxi-hourly").serialize() ;

$.ajax({
url:'<?php echo base_url();?>admin/insert_taxi',
type:'post',
data:value,
success:function(res){
	$(".taxi").show();
console.log(res);
if(res==0){
		$(".taxi").html('<p class="error">Error</p>');
	setTimeout(function(){$(".taxi").hide(); }, 3000);
}else if(res==2){
		$(".taxi").html('<p class="error">Car Type exists</p>');
	setTimeout(function(){$(".taxi").hide(); }, 3000);
}
else{

	
	
	
	
$(".taxi").html('<p class="success">Taxi Details Saved Successfully</p>');
setTimeout(function(){$(".taxi").hide(); }, 1500);
$('#taxi-hourly')[0].reset();
}
}
});
});
});





</script>


</body>

</html>
